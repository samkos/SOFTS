Free Launch Bar

INSTALLATION NOTES

If you are using 32-bit Windows run freelaunchbar32.exe to install Free Launch Bar.
freelaunchbar64.msi is for 64-bit Windows

http://www.freelaunchbar.com
